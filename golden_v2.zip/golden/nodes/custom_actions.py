"""
Golden Custom Action Nodes — SDK v0.5.3 (ft/kts/deg units)

Core: Proportional Navigation + Energy Management
Units: distance=ft, altitude=ft, velocity=kts, angles=0-1 normalized (×180 for deg)
"""

import logging
import py_trees

logger = logging.getLogger(__name__)


class BaseAction(py_trees.behaviour.Behaviour):
    """Custom action base class"""

    def __init__(self, name: str):
        super().__init__(name)
        self.blackboard = self.attach_blackboard_client()
        self.blackboard.register_key(key="observation", access=py_trees.common.Access.READ)
        self.blackboard.register_key(key="action", access=py_trees.common.Access.WRITE)

    def set_action(self, delta_altitude_idx: int, delta_heading_idx: int, delta_velocity_idx: int):
        self.blackboard.action = [delta_altitude_idx, delta_heading_idx, delta_velocity_idx]


def _heading_from_tau(tau_deg: float, gain: float = 1.0) -> int:
    """Convert tau angle (degrees) to heading index [0-8] with proportional gain."""
    cmd = tau_deg * gain
    idx = int(round(cmd / 22.5)) + 4
    return max(0, min(8, idx))


def _heading_pd(tau_deg: float, tau_rate: float,
                kp: float = 0.8, kd: float = 0.3) -> int:
    """PD controller on tau: proportional + derivative."""
    cmd = kp * tau_deg + kd * tau_rate
    idx = int(round(cmd / 22.5)) + 4
    return max(0, min(8, idx))


class PNPursuit(BaseAction):
    """PN-enhanced pursuit with energy management (ft/kts units)."""

    def __init__(self, name: str = "PNPursuit",
                 kp: float = 1.0,
                 kd: float = 0.4,
                 close_range_ft: float = 4921.0,    # 1500m
                 wez_max_ft: float = 3000.0,         # 914m
                 wez_min_ft: float = 500.0,           # 152m
                 far_range_ft: float = 13123.0):      # 4000m
        super().__init__(name)
        self.kp = kp
        self.kd = kd
        self.close_range = close_range_ft
        self.wez_max = wez_max_ft
        self.wez_min = wez_min_ft
        self.far_range = far_range_ft
        self.prev_tau = None

    def update(self) -> py_trees.common.Status:
        try:
            obs = self.blackboard.observation

            tau = obs.get("tau_deg", 0.0) * 180.0        # 0-1 → degrees
            ata = obs.get("ata_deg", 1.0) * 180.0        # 0-1 → degrees
            distance = obs.get("distance_ft", 30000.0)    # ft
            alt_gap = obs.get("alt_gap_ft", 0.0)          # ft
            altitude = obs.get("ego_altitude_ft", 16000.0) # ft
            velocity = obs.get("ego_vc_kts", 389.0)       # kts
            closure = obs.get("closure_rate_kts", 0.0)     # kts

            # --- HEADING: PD on tau ---
            if self.prev_tau is not None:
                tau_rate = (tau - self.prev_tau) / 0.2
                kp = self.kp * (1.5 if distance < self.close_range else 1.0)
                heading_idx = _heading_pd(tau, tau_rate, kp, self.kd)
            else:
                heading_idx = _heading_from_tau(tau, self.kp)
            self.prev_tau = tau

            # --- ALTITUDE: situation-dependent ---
            if altitude < 2625:                           # 800m → 2625ft
                delta_alt = 4  # Emergency climb
            elif ata < 30 and distance > self.wez_max:
                delta_alt = 1 if altitude > 6562 else 2   # 2000m → 6562ft
            elif ata > 90:
                delta_alt = 2
            elif alt_gap > 656:                            # 200m → 656ft
                delta_alt = 2
            elif alt_gap > -328:                           # -100m → -328ft
                delta_alt = 2
            else:
                delta_alt = 3

            # --- SPEED: ATA-aware ---
            if distance < self.wez_min:
                delta_vel = 0
            elif distance < self.wez_max and ata < 20:
                delta_vel = 1
            elif ata < 30 and distance > self.close_range:
                delta_vel = 4
            elif ata > 60 and distance < self.close_range:
                delta_vel = 1
            elif distance < self.close_range:
                delta_vel = 2
            elif distance < self.far_range:
                delta_vel = 3
            else:
                delta_vel = 4

            # Closure rate override
            if closure < -58 and distance > self.wez_max:  # -30 m/s → -58 kts
                delta_vel = max(delta_vel, 4)

            self.set_action(delta_alt, heading_idx, delta_vel)
            return py_trees.common.Status.SUCCESS

        except Exception as e:
            logger.warning(f"PNPursuit error: {e}")
            self.set_action(2, 4, 2)
            return py_trees.common.Status.FAILURE


class PNAttack(BaseAction):
    """Close-range precision engagement for Gun WEZ (ft/kts units).

    WEZ: ATA < 12deg, 500-3000ft.
    """

    def __init__(self, name: str = "PNAttack",
                 kp: float = 1.2,
                 kd: float = 0.5):
        super().__init__(name)
        self.kp = kp
        self.kd = kd
        self.prev_tau = None

    def update(self) -> py_trees.common.Status:
        try:
            obs = self.blackboard.observation

            tau = obs.get("tau_deg", 0.0) * 180.0         # 0-1 → degrees
            ata = obs.get("ata_deg", 1.0) * 180.0         # 0-1 → degrees
            distance = obs.get("distance_ft", 3000.0)     # ft
            alt_gap = obs.get("alt_gap_ft", 0.0)          # ft
            closure = obs.get("closure_rate_kts", 0.0)     # kts

            # --- HEADING: tight PD ---
            if self.prev_tau is not None:
                tau_rate = (tau - self.prev_tau) / 0.2
                heading_idx = _heading_pd(tau, tau_rate, self.kp, self.kd)
            else:
                heading_idx = _heading_from_tau(tau, self.kp)
            self.prev_tau = tau

            # --- ALTITUDE: minimal, keep stable ---
            if alt_gap > 656:             # 200m → 656ft
                delta_alt = 2
            elif alt_gap > -328:          # -100m → -328ft
                delta_alt = 3
            else:
                delta_alt = 2

            # --- SPEED: decelerate for stable gun platform ---
            if distance < 500:            # 152m → 500ft
                delta_vel = 0
            elif distance < 1312:         # 400m → 1312ft
                delta_vel = 0 if closure > 58 else 1   # 30 m/s → 58 kts
            elif distance < 2297:         # 700m → 2297ft
                delta_vel = 1
            elif distance < 3000:         # 914m → 3000ft
                delta_vel = 2
            else:
                delta_vel = 3

            self.set_action(delta_alt, heading_idx, delta_vel)
            return py_trees.common.Status.SUCCESS

        except Exception as e:
            logger.warning(f"PNAttack error: {e}")
            self.set_action(2, 4, 2)
            return py_trees.common.Status.FAILURE


class EnergyRecovery(BaseAction):
    """Energy recovery maneuver when energy state is low (kts units)."""

    def __init__(self, name: str = "EnergyRecovery",
                 min_velocity_kts: float = 389.0,      # 200 m/s
                 critical_velocity_kts: float = 291.0):  # 150 m/s
        super().__init__(name)
        self.min_velocity = min_velocity_kts
        self.critical_velocity = critical_velocity_kts

    def update(self) -> py_trees.common.Status:
        try:
            obs = self.blackboard.observation

            tau = obs.get("tau_deg", 0.0) * 180.0
            velocity = obs.get("ego_vc_kts", 389.0)       # kts
            altitude = obs.get("ego_altitude_ft", 16000.0) # ft

            heading_idx = _heading_from_tau(tau, 0.5)

            if velocity < self.critical_velocity:
                delta_alt = 1
                delta_vel = 4
            elif velocity < self.min_velocity:
                delta_alt = 1 if altitude > 4921 else 2   # 1500m → 4921ft
                delta_vel = 4
            else:
                delta_alt = 2
                delta_vel = 3

            # Hard Deck safety
            if altitude < 2625:            # 800m → 2625ft
                delta_alt = 4
                delta_vel = 3

            self.set_action(delta_alt, heading_idx, delta_vel)
            return py_trees.common.Status.SUCCESS

        except Exception as e:
            logger.warning(f"EnergyRecovery error: {e}")
            self.set_action(2, 4, 3)
            return py_trees.common.Status.FAILURE


class AdaptiveAction(BaseAction):
    """Reactive counter-strategy action (ft/kts units)."""

    def __init__(self, name: str = "AdaptiveAction"):
        super().__init__(name)
        self._prev_tau = None

    def update(self) -> py_trees.common.Status:
        try:
            obs = self.blackboard.observation

            aa       = obs.get('aa_deg', 0.5) * 180
            ata      = obs.get('ata_deg', 0.5) * 180
            tau      = obs.get('tau_deg', 0.0) * 180
            distance = obs.get('distance_ft', 16000.0)      # ft
            tc_type  = obs.get('tc_type', '2-circle')
            overshoot = obs.get('overshoot_risk', False)
            side_flag = int(obs.get('side_flag', 0))
            alt_gap   = obs.get('alt_gap_ft', 0.0)          # ft
            ego_alt   = obs.get('ego_altitude_ft', 16000.0)  # ft
            closure   = obs.get('closure_rate_kts', 0.0)     # kts
            energy_diff = obs.get('energy_diff_ft', 0.0)     # ft

            if self._prev_tau is not None:
                tau_rate = (tau - self._prev_tau) / 0.2
            else:
                tau_rate = 0.0
            self._prev_tau = tau

            if aa < 60 and ata < 70:
                da, dh, dv = self._offensive(tau, tau_rate, alt_gap, distance, ata)
            elif aa > 140:
                da, dh, dv = self._defensive(side_flag, ego_alt)
            elif overshoot:
                da, dh, dv = self._high_yoyo(tau, side_flag)
            elif distance < 9843:                            # 3000m → 9843ft
                if tc_type == '1-circle':
                    da, dh, dv = self._one_circle(tau, tau_rate)
                else:
                    da, dh, dv = self._two_circle(tau, energy_diff, alt_gap)
            else:
                da, dh, dv = self._lag_pursuit(tau, tau_rate, alt_gap, distance, closure, ego_alt)

            self.set_action(da, dh, dv)
            return py_trees.common.Status.SUCCESS

        except Exception as e:
            logger.warning(f"AdaptiveAction error: {e}")
            self.set_action(2, 4, 2)
            return py_trees.common.Status.FAILURE

    def _offensive(self, tau, tau_rate, alt_gap, distance, ata):
        kp = 1.3 if distance > 6562 else 1.1             # 2000m → 6562ft
        dh = _heading_pd(tau, tau_rate, kp=kp, kd=0.2)

        if alt_gap > 492:                                  # 150m → 492ft
            da = 3
        else:
            da = 2

        if ata < 20 and distance < 4921:                   # 1500m → 4921ft
            dv = 2
        elif distance > 9843:                              # 3000m → 9843ft
            dv = 4
        else:
            dv = 3

        return da, dh, dv

    def _defensive(self, side_flag, ego_alt):
        if side_flag == 1:
            dh = 0
        elif side_flag == -1:
            dh = 8
        else:
            dh = 0

        da = 1 if ego_alt > 3281 else 2                   # 1000m → 3281ft
        dv = 4

        return da, dh, dv

    def _high_yoyo(self, tau, side_flag):
        dh = _heading_from_tau(tau, gain=0.5)
        da = 4
        dv = 1
        return da, dh, dv

    def _one_circle(self, tau, tau_rate):
        dh = _heading_pd(tau, tau_rate, kp=1.5, kd=0.3)
        da = 2
        dv = 1
        return da, dh, dv

    def _two_circle(self, tau, energy_diff, alt_gap):
        dh = _heading_from_tau(tau, gain=0.9)

        if energy_diff > 1640:                             # 500m → 1640ft
            da = 3
        else:
            da = 2

        dv = 3
        return da, dh, dv

    def _lag_pursuit(self, tau, tau_rate, alt_gap, distance, closure, ego_alt):
        dh = _heading_pd(tau, tau_rate, kp=0.8, kd=0.3)

        if ego_alt < 2625:                                 # 800m → 2625ft
            da = 4
        elif alt_gap > 656:                                # 200m → 656ft
            da = 3
        elif alt_gap < -656:                               # -200m → -656ft
            da = 2
        else:
            da = 2

        if distance > 13123:                               # 4000m → 13123ft
            dv = 4
        elif distance > 6562:                              # 2000m → 6562ft
            dv = 3
        elif closure < -39:                                # -20 m/s → -39 kts
            dv = 4
        else:
            dv = 2

        return da, dh, dv
